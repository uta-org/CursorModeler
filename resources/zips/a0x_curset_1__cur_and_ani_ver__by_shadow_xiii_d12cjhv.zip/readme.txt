1. No CursorXP
This version does not require CursorXP, you can change cursors in Control Panel of your PC.

2. CD BUSY
To use cd_busy cursor you will have to modify [use ResHacker] your user32.dll file, located in c:/windows/system32. For more info visit Google.

3. DRAG & DROP
To change drag & drop cursors you need to modify [ResHacker] ole32.dll, which can be found in c:/windows/system32 directory. 

Have a nice day! ;-)

25.07.2007
a0x

SHADOW-XIII (No CursorXP version)
____________________
azeroiks@gmail.com
http://www.a0x.info
