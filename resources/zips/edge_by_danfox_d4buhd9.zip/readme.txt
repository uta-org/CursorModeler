EDGE cursor set by eFOX

How to install
1. Extract the archive to a temporary folder.
2. Right click the "EDGE hikari/yuki.inf" file and click on "Install".
3. Choose the cursor set in the control panel mouse applet. It appears as "EDGE hikari/yuki".

For personal use only.
Any other use (including the reproduction, modification, distribution, transmission, republication, display
or performance) of the content (in whole or in parts) is strictly prohibited without my written permission.
Not to be shared or uploaded on other websites.