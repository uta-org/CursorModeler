Forma Nova, by iixo || 2007 || www.iixo.6x.to


Install:
--------
- Extract the archive to a temporary folder.
- Right click the "Install.inf" file and click on "Install"
- Choose the cursorset in the control panel mouse applet
  It appears as "Forma Nova (Default)"
- If necessary, choose alternative cursors which are in the "alternatives" folder

Troubleshooting:
----------------
When the shadow on the cursors look like crap (which can happen on
some systems) you should turn 2D hardware acceleration a nod down.
You can do that this way:
- Display Properties -> Settings -> Advanced -> Troubleshoot
- Set "Hardware Acceleration" one nod down

Legal:
------
Some rights reserved. This work is licensed under a
Creative Commons Attribution-Noncommercial-No Derivative Works 2.5 License.

http://creativecommons.org/licenses/by-nc-nd/2.5/