
Install:
--------
- Extract the archive to a temporary folder.
- Right click the "Install.inf" file and click on "Install"
- Choose the cursorset in the control panel mouse applet
  It appears as "Extenza Crystal"

Troubleshooting:
----------------
When the shadow on the cursors look bad (which can happen on
some systems) you should turn 2D hardware acceleration a nod down.
You can do that this way:
- Display Properties -> Settings -> Advanced -> Troubleshoot
- Set "Hardware Acceleration" one nod down

