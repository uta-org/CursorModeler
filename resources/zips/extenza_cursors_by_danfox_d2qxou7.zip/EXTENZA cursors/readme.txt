EXTENZA cursor pack by eFOX

Thank you for downloading.

FOR PERSONAL USE ONLY
These cursors may be installed and used on your personal computer only.
Any other use (including the reproduction, modification, distribution, transmission, republication, display
or performance) of the content (in whole or in parts) is strictly prohibited without my written permission.
THESE CURSORS ARE NOT TO BE SHARED OR UPLOADED ON OTHER WEBSITES.


Install:
--------
- Extract the archive to a temporary folder.
- Right click the "Install.inf" file and click on "Install"
- Choose the cursorset in the control panel mouse applet
  It appears as "EXTENZA cursors - Blue/Orange"

Troubleshooting:
----------------
When the shadow on the cursors look bad (which can happen on
some systems) you should turn 2D hardware acceleration a nod down.
You can do that this way:
- Display Properties -> Settings -> Advanced -> Troubleshoot
- Set "Hardware Acceleration" one nod down


Check out EXTENZA winamp skin & Sony Ericsson theme at efox-hun.deviantart/gallery